#pragma once
#ifndef ASSEMBLY_H
#define ASSEMBLY_H

#include <string>
#include <vector>
#include "Variable.h"
using namespace std;


string inlineassembly();
string assemblyfor(int i, int tmp);
string assemblyif(int i, int tmp);




#endif // !ASSEMBLY_H
