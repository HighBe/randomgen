#pragma once
#ifndef FRAME_H
#define FRAME_H

#include <string>

using namespace std;

string getFrame();
#endif // !FRAME_H

