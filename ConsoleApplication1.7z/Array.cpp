#include "Array.h"

string genArray(vector<Variable>& VarList, int i) {
    string res;
    Variable tmpV;

    //ȷ�������С,��С1 ���3
    int tmp = rand() % 3 + 1;
    //����ÿһά��Ӧ�Ĵ�С
    int* a = new int[tmp];
    for (int i = 0; i < tmp; i++) {
        a[i] = rand() % 5 + 5;
    }
    string tmps;
    string arrayName = "array_" + getName(i);
    tmpV.a = a[0];
    tmps += "[" + to_string(a[0]) + "]";
    if (tmp > 1) {
        tmpV.b = a[1];
        tmps = "[" + to_string(a[1]) + "]" + tmps;
    }
    if (tmp > 2) {
        tmpV.c = a[2];
        tmps = "[" + to_string(a[2]) + "]" + tmps;
    }
    //ȷ����������
    if (rand() % 2 == 0) {//uint
        res = "uint256" + tmps + arrayName + " = [";
        for (int i = 0; i < tmpV.a; i++) {
            res += "[";
            for (int j = 0; j < tmpV.b; j++) {
                res += "[";
                for (int k = 0; k < tmpV.c; k++) {//����һ��ֻ��������
                    res += to_string(rand() % 50);
                    if (k != tmpV.c - 1) res += ",";
                }
                res += "]";
                if (i != tmpV.b - 1) res += ",";
            }
            res += "]";
            if (i != tmpV.a - 1) res += ",";
        }
        res += "];";

    }
    else {
        res = "int256" + tmps + arrayName + " = ";
        for (int i = 0; i < tmpV.a; i++) {
            res += "[";
            for (int j = 0; j < tmpV.b; j++) {
                res += "[";
                for (int k = 0; k < tmpV.c; k++) {//����һ��ֻ��������
                    if (rand() % 2 == 0) res += "-";//int256���ɸ���
                    res += to_string(rand() % 50);
                    if (k != tmpV.c - 1) res += ",";
                }
                res += "]";
                if (i != tmpV.b - 1) res += ",";
            }
            res += "]";
            if (i != tmpV.a - 1) res += ",";
        }
        res += "];";
    }
    VarList.emplace_back(tmpV);
    return res;
}