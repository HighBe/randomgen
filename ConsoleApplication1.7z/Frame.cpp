#include <vector>

#include "Frame.h"
#include "Test.h"
#include "Function.h"
#include "Variable.h"


extern string testtestevent;   //ֻ��¼״̬����
extern string testtestemit;
extern vector<Variable> VariableList;//���״̬����

string getFrame() {

    //ÿ����Լ��ͨ�̶��Ĳ���
    string res;
    res += "//SPDX-License-Identifier: GPL-3.0\n"
        "pragma solidity ^0.8.0;\ncontract ContractName{\n\t";
    //"constructor(){}\n\t";
//����evnet�����Ƚ����ݣ��ж�compiler�Ƿ���bug
//res += "\tevent testtest(int256 a);\n";

//�������������״̬����

    int count = rand() % 5 + 3;

    for (int i = 0; i <= count; i++) {
        res += genVariable(VariableList, i, false);
    }

    testtestevent.clear();
    testtestemit.clear();
    testtestevent += "event testtest(";
    testtestemit += "emit testtest(";
    //for (int i = 0; i < 10; i++) {
    //    testtestevent += VariableList[i].Typename + " " + VariableList[i].Variablename;
    //    testtestemit += VariableList[i].Variablename;
    //    if (i != 9) {
    //        testtestevent += ",";
    //        testtestemit += ",";
    //    }
    //}

    for (vector<Variable>::iterator iter = VariableList.begin(); iter != VariableList.end(); iter++) {
        testtestevent += iter->Typename + " " + iter->Variablename;
        testtestemit += iter->Variablename;
        if (iter->Variablename != (VariableList.end() - 1)->Variablename) {
            testtestevent += ",";
            testtestemit += ",";
        }
    }

    testtestevent += ");\n";
    testtestemit += ");\n";
    res += testtestevent;
    //res += to_string(VariableList.size()) + "\n";
    testtestevent.clear();
    //����3������
    count = 3;  //rand() % 10 + 1;
    for (int i = 0; i < count; i++) {
        res += genfunc("func_" + getName(i));
    }

    res += "}";
    VariableList.clear();
    return res;
}

