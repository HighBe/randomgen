#pragma once
#ifndef BLOCK_H
#define BLOCK_H

#include <string>

using namespace std;

string block_make_random();

#endif // !BLOCK_H