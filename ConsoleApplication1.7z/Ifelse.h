#pragma once
#ifndef IFELSE_H
#define IFELSE_H


#include <string>
using namespace std;

string returnInt(string int1, string int2);
string returnBool(string int1, string int2);
string boolreturnBool(string bool1, string bool2);
string ifelse_make_random();


#endif // !IFELSE_H
