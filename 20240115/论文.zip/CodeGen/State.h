#pragma once
#ifndef STATE_H
#define STATE_H

#include <string>
using namespace std;

string state_make_random();

#endif