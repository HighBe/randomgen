#pragma once
#ifndef TEST_H
#define TEST_H
#include <string>
using namespace std;

string generateScript(int i);



#endif // !TEST_H
