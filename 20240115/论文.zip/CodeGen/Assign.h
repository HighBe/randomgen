#pragma once
#ifndef ASSIGN_H
#define ASSIGN_H

string assign_make_random();

#endif // !ASSIGN_H
