#include "Block.h"
#include "Assign.h"
#include "Ifelse.h"
#include "Loop.h"

extern int blockcount;
extern int inLoop;

string block_make_random() {
    //�����¿飬��ȼ�һ
    blockcount++;
    string res;
    //�������õĿ����������,��ֹ�����Ĵ���
    if (blockcount >= 5) {
        int l = rand() % 10;
        for (int i = 0; i < l; i++)
            res += assign_make_random();
        return res;
    }
    int tmp = rand() % 5;
    for (int i = 0; i <= tmp; i++) {
        int t = rand() % 3;
        switch (t) {
        case 0://assign
            res += assign_make_random();
            break;
        case 1://for
            if (inLoop <= 3) {
                res += loop_make_random();
            }
            break;
        case 2://if
            res += ifelse_make_random();
            break;
        }
    }
    blockcount--;
    //���飬��ȼ�һ
    return res;
}

