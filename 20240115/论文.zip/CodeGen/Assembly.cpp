#include "Assembly.h"
#include "Function.h"

extern vector<Variable> AssemblyVarList; // ������������еı���

extern vector<Variable> VariableList;//���״̬����
extern vector<Variable> LocalVarList;//��žֲ�����
extern vector<Variable> GlobalVarList;//���ȫ�ֱ���
extern vector<Variable> ArrayList;
extern vector<sfunction> FuncReturnList;//��ź������ͷ���ֵ����
extern string infunc;//��¼��ǰ�������ĸ������е����ݣ�������õ�ǰ����

string inlineassembly() {
    /*
    let x := y
    let res := add(x,div(x,y))
    */
    string res = "assembly{\n";
    //���������������
    int tmp = rand() % 5;
    for (int i = 0; i < tmp; ++i) {
        string varname = "aa" + getName(i);
        int varval = rand() % 10;
        res += "let " + varname + ":= " + to_string(varval) + "\n";
        AssemblyVarList.emplace_back(Variable("assemblyvar", varname, varval));
    }
    switch (rand() % 2) {
    case 0:
        assemblyfor(0, tmp);
        break;
    case 1:
        assemblyif(0, tmp);
        break;
    }
    switch(rand() % 3){
    case 0:
        res += "return (0,0)";
        break;
    case 1:
        res += "return (" + to_string(rand()%10) + "," + to_string(rand()%8 * 8) + ")";
        break;
    case 3:
        break;
    }
    res += "}";
    return res;
}
// ��ȡ��ֵ
string getLvalue(){
    string res = "";
    int ls = VariableList.size() + LocalVarList.size() + AssemblyVarList.size() + ArrayList.size();//�Ⱥ���߿�����״̬�����;ֲ�����
    int tmp = rand() % ls;
    if(tmp < VariableList.size()){
        res += VariableList[tmp].Variablename;
    }else if(tmp < VariableList.size() + LocalVarList.size()){
        res += LocalVarList[tmp-VariableList.size()].Variablename;
    }else if(tmp < VariableList.size() + LocalVarList.size() + AssemblyVarList.size()){
        res += AssemblyVarList[tmp - VariableList.size() - LocalVarList.size()].Variablename;
    }else {
        Variable tmpv;
        tmpv = ArrayList[tmp - VariableList.size() - LocalVarList.size() - AssemblyVarList.size()];
        res += tmpv.Variablename + "[" + to_string(rand() % tmpv.a) + "]";
    }
    return res;
}
// ��ȡ��ֵ
string getRvalue(){
    string res;
    int rs = VariableList.size() + LocalVarList.size() + AssemblyVarList.size() + ArrayList.size();//�Ⱥ���߿�����״̬�����;ֲ�����
    int tmp = rand() % (rs + rs/2);
    if(tmp < VariableList.size()){
        res = VariableList[tmp].Variablename;
    }else if(tmp < VariableList.size() + LocalVarList.size()){
        res = LocalVarList[tmp-VariableList.size()].Variablename;
    }else if(tmp < VariableList.size() + LocalVarList.size() + AssemblyVarList.size()){
        res = AssemblyVarList[tmp - VariableList.size() - LocalVarList.size()].Variablename;
    }else if(tmp < rs){
        Variable tmpv =  ArrayList[tmp - VariableList.size() - LocalVarList.size() - AssemblyVarList.size()];
        res += tmpv.Variablename + "[" + to_string(rand() % tmpv.a) + "]";
    }else{
        res = to_string(rand() % 100);
    }
    return res;
}
string AssemblyKeccak(){
    string res = "keccak256(";
    res += to_string(rand() % 10) + ",";
    res += to_string(rand() % 33) + ")";
    return res;
}
string mload(){
    string res = "mload("+ to_string(rand()%10) + ")";
    return res;
}
string AssemblyOp(int deep){
    string res = "";
    if(deep >= 3) return to_string(rand() % 50 + 1);
    if(deep == 0) res += getLvalue() + " := ";
    switch (rand() % 4)
    {
    case 0:
        res +=  + "add(";
        break;
    case 1: 
        res +="sub(";
        break;
    case 2:
        res +="mul(";
        break;
    case 3:
        res +="div(";
        break;
    }
    switch (rand()%5)
    {
    case 0:
        res += getRvalue();
        break;
    case 1:
        res += mload();
        break;
    case 2:
        res += AssemblyKeccak();
        break;
    case 3:
        res += to_string(rand() % 50);
        break;
    case 4:
        res += AssemblyOp(deep+1);
        break;
    }
    res += ",";
    switch (rand() % 5)
    {
    case 0:
        res += getRvalue();
        break;
    case 1:
        res += mload();
        break;
    case 2:
        res += AssemblyKeccak();
        break;
    case 3:
        res += to_string(rand() % 50);
        break;
    case 4:
        res += AssemblyOp(deep+1);
        break;
    }
    res += ")";
    return res;
}
string AssemblyMstore(){
    string res = "";
    res += "mstore(" + to_string(rand()%10) + "," ;
    switch (rand() % 4)
    {
    case 0:
        res += to_string(rand() % 50);
        break;
    case 1:
        res += getRvalue();
        break;
    case 2:
    case 3:
        res += AssemblyOp(0);
        break;
    }
    res += ")";
    return res;
}
string AssemblyAssign(int l){
    string res = "";
    for(int m = 0;m < l;++ m){
        switch(rand() % 4){
        case 0:
        case 1:
        case 2:
            res += AssemblyOp(0);
            break;
        case 3:
            res += AssemblyMstore();
            break;
        case 4:
            res += getLvalue() + ":=" + mload();
            break;
        }
    }
    return res;
}
string assemblyfor(int i, int tmp) { // i�������,tmp��ʾ�ж��ٸ�����
    if (i > 3)return "";
    string var = "assemblyfor_";
    var.push_back('i' + i);
    string res = "for {let " + var + " := 0} lt(" + var + "," + to_string(rand() % 10) + ") {" + var + " := add(" + var +",1)}\n{\n";
    // ������������
    int l = rand() % 5;
    res += AssemblyAssign(l);
    switch (rand() % 2) {
    case 0:
        res += assemblyfor(i + 1, tmp);
        break;
    case 1:
        res += assemblyif(i + 1, tmp);
        break;
    }
    l = rand() % 5;
    res += AssemblyAssign(l);
    res += "}\n";
    return res;
}
string assemblyif(int i, int tmp) {
    string res;
    if (i > 3) return res;
    switch (rand() % 3)
    {
    case 0:
        res += "if eq(";
        break;
    case 1:
        res += "if lt(";
        break;
    case 2:
        res += "if gt(";
        break;
    }
    res += AssemblyVarList[rand() % tmp].Variablename + "," + AssemblyVarList[rand() % tmp].Variablename + ")\n{\n";
    // ������������
    int l = rand() % 5;  
    res += AssemblyAssign(l);
    switch (rand() % 2) {
    case 0:
        res += assemblyif(i + 1, tmp);
        break;
    case 1:
        res += assemblyfor(i + 1, tmp);
        break;
    }
    l = rand() % 5;
    res += AssemblyAssign(l);
    res += "}\n";
    return res;
}