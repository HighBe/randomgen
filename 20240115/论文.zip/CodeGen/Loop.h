#pragma once
#ifndef LOOP_H
#define LOOP_H

#include <string>
using namespace std;

string loop_make_random();


#endif // !LOOP_H
