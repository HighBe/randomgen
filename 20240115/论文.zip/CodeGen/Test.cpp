#include "Test.h"
#include "Variable.h"


string generateScript(int i) {
    string res;
    res = "const {expect} = require(\"""chai\""");\n" \
        "const {loadFixture} = require(\"""@nomicfoundation/hardhat-network-helpers\""");\n" \
        "const web3 = require(\"""web3\""");\n\n" \
        "describe(\"ContractName\",function(){\n";
    res += "\tasync function deployOneYearLockFixture(){\n" \
        "\t\tconst _Contract = await ethers.getContractFactory(\"ContractName\");\n" \
        "\t\tconst [account0,account1,account2] = await ethers.getSigners();\n" \
        "\t\tconst _contract = await _Contract.deploy();\n" \
        "\t\treturn {_contract,account0,account1,account2};" \
        "\n\t}\n\n";
    res += "\tdescribe(\"func_" + getName(i) + "\",function(){\n" \
        "\t\tit(\"""testing func_" + getName(i) + "\",async function(){\n" \
        "\t\t\tconst {_contract,account0,account1,account2} = await loadFixture(deployOneYearLockFixture);\n" \
        "\t\t\tawait _contract.connect(account0).func_" + getName(i) + "();\n" \
        "\t\t});\n" \
        "\t});\n";
    //res += "\tconst filter = { \n\t\t address:_contract.address, \n\t\t topic:[ethers.utils.id('')]\n\t};\n" \
    //    "\tconst events = await _contract.provider.getLogs(filter);\n" \
    //    "\tconst parseEvents = events.map((event)=>_contract.interface.parseLog(event));\n" \
    //    "\tfor(var i = 0;i < parseEvents.length;i++){\n" \
    //    "\t\tif(parseEvents[i].name == \"testtestglobal\"){\n" \
    //    "\t\t\tfor(var j = 0;j < parseEvents[i].args.length;j ++){\n" \
    //    "\t\t\t\tconsole.log('',parseEvents[i].args[j]);\n" \
    //    "\t\t\t}\n\t\t}\n" \
    //    "\t\tif(parseEvents[i].name == \"testtestlocal\"){\n" \
    //    "\t\t\tfor(var j = 0;j < parseEvents[i].args.length;j ++){\n" \
    //    "\t\t\t\tconsole.log('',parseEvents[i].args[j]);\n" \
    //    "\t\t\t}\n\t\t}\n\t}\n";
    res += "});";
    return res;
}