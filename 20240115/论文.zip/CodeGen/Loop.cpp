#include "Loop.h"
#include "Block.h"

extern int inLoop;

string loop_make_random() {
    string res;
    string varname;
    if (inLoop >= 3) return res;
    switch (inLoop)
    {
    case 0:
        varname = "for_i";
        break;
    case 1:
        varname = "for_j";
        break;
    case 2:
        varname = "for_k";
        break;
    }
    inLoop++;
    res += "for(uint256 " + varname + "=0;" + varname + "<" +
        to_string(rand() % 10 + 1) + ";" + varname + "++)\n{\n";

    //�м����block����һϵ�п��е�����
    res += block_make_random();


    res += " \n }\n";
    inLoop--;

    return res;
}