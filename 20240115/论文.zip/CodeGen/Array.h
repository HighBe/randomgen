#pragma once
#ifndef ARRAY_H
#define ARRAY_H

#include <string>
#include <vector>
#include "Variable.h"
using namespace std;

string genArray(vector<Variable>& VarList, int i);
string mload();
string AssemblyAdd();
string AssemblyMul();
#endif // !ARRAY_H
