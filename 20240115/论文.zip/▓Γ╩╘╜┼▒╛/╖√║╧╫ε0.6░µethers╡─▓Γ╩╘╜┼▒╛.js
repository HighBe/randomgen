const {expect} = require("chai");
const {loadFixture} = require("@nomicfoundation/hardhat-network-helpers");
const web3 = require("web3");

describe("ContractName",function(){
	async function deployOneYearLockFixture(){
		const _Contract = await ethers.getContractFactory("ContractName");
		const [account0,account1,account2] = await ethers.getSigners();
		const _contract = await _Contract.deploy();
		return {_contract,account0,account1,account2};
	}
	// 符合最新版hardhat和0.6版ethers的测试脚本
	describe("func_a",function(){
		it("testing func_a",async function(){
			const {_contract,account0,account1,account2} = await loadFixture(deployOneYearLockFixture);
			// console.log(ethers.getAddress() );
			await _contract.connect(account0).func_a();
			// const filter = { 
			// 	address:_contract.runner.address, 
			// 	topic:[null]
			// };
			const filter = {
				fromBlock:0,
				toBlock:50
			}
			// console.log(ethers.provider.getLogs(filter));
			const events = await _contract.runner.provider.getLogs(filter);
			const parseEvents = events.map((event)=>_contract.interface.parseLog(event));
			for(var i = 0;i < parseEvents.length;i++){
				if(parseEvents[i].name == "testtest"){
					for(var j = 0;j < parseEvents[i].args.length;j ++){
						console.log('',parseEvents[i].args[j]);
					}
				}
			}
		});
	});
});